import pandas as pd
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split

# Load the main CSV file containing file names and target values
main_csv = pd.read_csv('/content/drive/MyDrive/abc.csv')

# Extract file names and target values
file_names = main_csv['file_name'].tolist()
target_values = main_csv['status'].values
base_path = '/content/drive/MyDrive/all'

# Split file names into training and testing sets
train_file_names, test_file_names, train_target_values, test_target_values = train_test_split(
    file_names, target_values, test_size=0.2, random_state=42)

train_data_list = []
for file_name in train_file_names:
    file_path = os.path.join(base_path, file_name)
    data = pd.read_csv(file_path)
    data = data.iloc[:, :-1]  # Exclude the last column
    data = data.astype('float32')  # Ensure float32 data type
    train_data_list.append(data.values)

test_data_list = []
for file_name in test_file_names:
    file_path = os.path.join(base_path, file_name)
    data = pd.read_csv(file_path)
    data = data.iloc[:, :-1]  # Exclude the last column
    data = data.astype('float32')  # Ensure float32 data type
    test_data_list.append(data.values)

train_data_array = np.array(train_data_list)
test_data_array = np.array(test_data_list)

train_data_array = train_data_array.astype('float32')
test_data_array = test_data_array.astype('float32')

# Define the CapsuleNetwork model
class CapsuleNetwork(models.Model):
    def _init_(self, input_shape_custom, routings=3, dim_capsule=[1152, 8, 1, 1], name='capsule_network', **kwargs):
        super(CapsuleNetwork, self)._init_(name=name, **kwargs)
        self.input_shape_custom = input_shape_custom
        self.routings = routings
        self.dim_capsule = dim_capsule

    def build(self, input_shape):
        self.primary_capsules = layers.Conv1D(filters=256, kernel_size=9, strides=1, padding='valid', activation='relu', name='primary_capsules')
        self.routing = [layers.Dense(units=self.dim_capsule[1], activation='softmax', name='routing_' + str(i)) for i in range(self.routings)]

    def call(self, inputs):
        x = self.primary_capsules(inputs)
        x = layers.Lambda(lambda z: tf.expand_dims(z, -1))(x)
        return x

# Instantiate the model
model = CapsuleNetwork(input_shape_custom=(23000, 4))
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(train_data_array, train_target_values, epochs=1, batch_size=32)

# Save the trained model as an .h5 file
model.save('/content/drive/MyDrive/saved_model')