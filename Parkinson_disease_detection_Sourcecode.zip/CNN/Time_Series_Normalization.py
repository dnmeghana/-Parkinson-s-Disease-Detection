import os
import pandas as pd

# Folder containing CSV files
folder_path = 'C:/Users/Dell/OneDrive/Desktop/capstone/parkinson_dataset/removed_UDPRS/processed/spiral/time_series_normalization/parkinson'

# Desired length for stretching
desired_length = 23000

# Loop through each CSV file in the folder
for filename in os.listdir(folder_path):
    if filename.endswith('.csv'):
        file_path = os.path.join(folder_path, filename)
        
        # Read CSV file into a pandas DataFrame
        df = pd.read_csv(file_path)
        
        # Calculate the number of times to duplicate the rows
        stretch_factor = desired_length // len(df) + 1
        
        # Duplicate rows to reach the desired length
        stretched_df = pd.concat([df] * stretch_factor, ignore_index=True)
        
        # Truncate the DataFrame to the desired length
        stretched_df = stretched_df[:desired_length]
        
        # Save the stretched DataFrame back to the CSV file
        stretched_df.to_csv(file_path, index=False)
        
        print(f"Stretched {filename} to a length of {desired_length} rows")