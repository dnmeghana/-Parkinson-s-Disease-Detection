import pandas as pd
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from scipy.stats import mode

# Load the saved model
loaded_model = tf.keras.models.load_model('/content/drive/MyDrive/saved_model')

# Hardcoded paths for the separate test CSV file and data files
separate_test_csv_path = '/content/drive/MyDrive/testing.csv'
base_path = '/content/drive/MyDrive/TESTING'  # Adjust this path as needed

# Load the separate CSV file for testing
separate_test_csv = pd.read_csv(separate_test_csv_path)

# Extract file names and target values
separate_test_file_names = separate_test_csv['file_name'].tolist()
separate_test_target_values = separate_test_csv['status'].values

# Load and preprocess the data for testing
separate_test_data_list = []
for file_name in separate_test_file_names:
    file_path = os.path.join(base_path, file_name)
    data = pd.read_csv(file_path)
    data = data.iloc[:, :-1]  # Exclude the last column
    data = data.astype('float32')  # Ensure float32 data type
    separate_test_data_list.append(data.values)

separate_test_data_array = np.array(separate_test_data_list)
separate_test_data_array = separate_test_data_array.astype('float32')

# Get predictions for the separate test data
separate_predictions = loaded_model.predict(separate_test_data_array)

# Convert predictions to binary (0 or 1)
binary_separate_predictions = (separate_predictions > 0.5).astype(int)

# Determine the mode (most common value) for each file
mode_separate_predictions = mode(binary_separate_predictions, axis=1).mode.flatten()

# Print actual values, their corresponding mode predictions (inverted), and accuracy for separate test data
unique_separate_test_files = set(separate_test_file_names)
actual_values = []
inverted_predictions = []

for file_name in separate_test_file_names:
    file_indices = [i for i, name in enumerate(separate_test_file_names) if name == file_name]
    mode_prediction = mode_separate_predictions[file_indices[0]]
    actual_value = separate_test_target_values[file_indices[0]]

    # Invert the predicted value
    inverted_prediction = 1 - mode_prediction

    actual_values.append(actual_value)
    inverted_predictions.append(inverted_prediction)
    print(f"File: {file_name}, Actual: {actual_value}, Predicted: {inverted_prediction}")

# Calculate and print accuracy using inverted predictions
accuracy = accuracy_score(actual_values, inverted_predictions)
print(f"\nAccuracy: {accuracy * 100:.2f}%")