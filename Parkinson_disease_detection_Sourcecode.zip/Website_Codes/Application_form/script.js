function submitApplicationForm() {
  const form = document.getElementById("applicationForm");
  const formData = new FormData(form);

  // Store the information entered in a text form
  const textForm = document.createElement("textarea");
  textForm.style.display = "none";
  document.body.appendChild(textForm);

  for (const [name, value] of formData) {
    textForm.value += `${name}: ${value}\n`;
  }

  // Submit the text form to the server
  fetch("/submit-application-form", {
    method: "POST",
    body: textForm.value,
  })
    .then((response) => response.json())
    .then((data) => {
      // Handle the response from the server
      if (data.success) {
        alert("Application form submitted successfully!");
      } else {
        alert("Error submitting application form!");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}
