// Animate the heading
const heading = document.querySelector('.heading');
heading.style.animation = 'fadeIn 1s';

// Animate the news images
const newsImages = document.querySelectorAll('.news-image');
newsImages.forEach((image) => {
    image.style.animation = 'fadeIn 1s';

    // Add a hover effect to images
    image.addEventListener('mouseover', () => {
        image.style.transform = 'scale(1.05)';
        image.style.boxShadow = '0 8px 12px rgba(0, 0, 0, 0.2)';
    });

    image.addEventListener('mouseout', () => {
        image.style.transform = 'scale(1.0)';
        image.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    });
});

// Animate the "Read More" buttons
const readMoreButtons = document.querySelectorAll('.image-link, .read-more-button');
readMoreButtons.forEach((button) => {
    button.style.animation = 'fadeIn 1s';

    // Add a hover effect to buttons
    button.addEventListener('mouseover', () => {
        button.style.backgroundColor = '#0056b3';
    });

    button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '#007BFF';
    });

    // Redirect to a URL when the "Read More" button is clicked
    if (button.classList.contains('read-more-button')) {
        button.addEventListener('click', () => {
            // Replace 'https://example.com/news-full' with the actual URL you want to link to
            window.location.href = 'https://www.medicalnewstoday.com/categories/parkinsons-disease';
        });
    }
});
