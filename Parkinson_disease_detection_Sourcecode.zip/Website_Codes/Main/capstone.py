import os
import cv2
import numpy as np
from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import threading
import tkinter as tk
from tkinter import filedialog
import csv  # Add this import
import tkinter as tk
from tkinter import filedialog
import librosa
import numpy as np
from flask import Flask, jsonify, render_template, request
from sklearn.preprocessing import StandardScaler
import joblib
import keras
import h5py
import tensorflow as tf
from keras.models import load_model
from tensorflow.keras.models import load_model
from scipy.stats import mode

app = Flask(__name__)

# Load your trained ML model
model_path = r'E:\CAPSTONE_PROJECT\Main\HTML_frontend\Main\static'
loaded_model = tf.saved_model.load(model_path)
inference = loaded_model.signatures["serving_default"]

model_path_dbn = 'E:\CAPSTONE_PROJECT\Main\Backend\dbn_model.h5'
model_dbn = load_model(model_path_dbn)

training_data = pd.read_csv(r"C:\Users\Shrutesh Reddy\OneDrive\Desktop\new_augmented_data.csv")

# Select the desired columns as features and target variable
features = training_data[['MDVP:Shimmer', 'MDVP:Shimmer(dB)', 'MDVP:APQ', 'Shimmer:DDA', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE']]
target = training_data['status']


# Create and fit MinMaxScaler
scaler = MinMaxScaler()

scaler1 = StandardScaler()
scaler1.fit(features)

# Global variables for mouse_callback
coordinates = []
mouse_pressed = False


def mouse_callback(event, x, y, flags, param):
    global mouse_pressed
    if event == cv2.EVENT_LBUTTONDOWN:
        mouse_pressed = True
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
    elif event == cv2.EVENT_LBUTTONUP:
        mouse_pressed = False
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
    elif event == cv2.EVENT_MOUSEMOVE and mouse_pressed:
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
        with open('E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates.csv', mode='a', newline='') as file:
            writer = csv.writer(file)
            if file.tell() == 0:
                writer.writerow(['X', 'Y', 'Z', 'Pressure'])
            writer.writerow([x, y, 0, np.random.randint(3, 950)])

def open_file_dialog():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    file_path = filedialog.askopenfilename(title="Select Image File", filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
    root.destroy()
    return file_path

def preprocess_csv(file_path, scaler):
    df = pd.read_csv(file_path)
    # Fit the scaler on the data
    scaler.fit(df)
    # Transform the data
    data = scaler.transform(df)
    # Assuming you want the first 4 columns as features
    X = data[:, :4]
    return X

def process_image(image_path):
    global coordinates
    coordinates = []  # Reset coordinates
    image = cv2.imread(image_path)
    cv2.namedWindow("Image")
    cv2.setMouseCallback("Image", mouse_callback)

    while True:
        cv2.imshow("Image", image)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            cv2.destroyAllWindows()  # Add this line to close the window
            break

    desired_length = 23000
    file_path = 'E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates.csv'
    df = pd.read_csv(file_path)
        
    # Calculate the number of times to duplicate the rows
    stretch_factor = desired_length // len(df) + 1
        
    # Duplicate rows to reach the desired length
    stretched_df = pd.concat([df] * stretch_factor, ignore_index=True)
        
    # Truncate the DataFrame to the desired length
    stretched_df = stretched_df[:desired_length]
        
    # Save the stretched DataFrame back to the CSV file
    stretched_df.to_csv(file_path, index=False)
        
    print(f"Stretched coordinates.csv to a length of {desired_length} rows")


    test_file_path = 'E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates.csv'

    # Move the creation of the scaler inside the function
    #scaler = MinMaxScaler()
    
    """data = pd.read_csv(test_file_path)
    test_dataset = scaler.fit_transform(data)

    X_test = test_dataset[:, :]
    y_test = test_dataset[:, :-1]

    # Reshape the input features
    input_shape = (X_test.shape[1], 1)
    X_test = X_test.reshape(X_test.shape[0], *input_shape)

    # Predict labels using the trained model
    y_pred = model.predict(X_test)
    y_pred_labels = np.round(y_pred)  # Round to 0 or 1

    if all(y_pred_labels == 1):
        #result = "Parkinson's"
        #return render_template('result.html', prediction=result)
        result="Parkinson"
        print(f"Predicted label: {result}")
        return "Parkinson"
    else:
        #result = "Without Parkinson's"
        #return render_template('result.html', prediction="No file uploaded")
        result="Without Parkinson"
        print(f"Predicted label: {result}")
        return "Without Parkinson"""
        # Preprocess the test dataset
    #X_test = preprocess_csv(test_file_path, scaler)

    # Predict label using the trained model
    """y_pred = model.predict(X_test)
    print("Predicted Probabilities:", y_pred)
    y_pred_label = np.round(y_pred)[0][0]  # Round to 0 or 1

    # Display the predicted label
    if y_pred_label == 1:
        prediction = "Parkinson's"
    else:
        prediction = "Without Parkinson's"
    print(f"Predicted label: {prediction}")

    return prediction"""

    # Preprocess the test dataset
    X_test = preprocess_csv(test_file_path, scaler)
    X_test = np.expand_dims(X_test, axis=0)
    # Predict label using the loaded TensorFlow model
    result = inference(tf.convert_to_tensor(X_test, dtype=tf.float32))
    y_pred_label = np.round(result['output_1'][0][0])  # Assuming 'output_1' is the output name
    y_pred_label = (y_pred_label > 0.5).astype(int)
    mode_separate_predictions = mode(y_pred_label, axis=1).mode.flatten()
    inverted_prediction = 1 - mode_separate_predictions
    inverted_predictions = []

    inverted_predictions.append(inverted_prediction)

    # Display the predicted label
    """if y_pred_label == 1:
        prediction = "Parkinson's"
    else:
        prediction = "Without Parkinson's"
    print(f"Predicted label: {prediction}")"""

    return  inverted_predictions[0]
    


def predict_from_tkinter():
    image_path = open_file_dialog()

    if image_path:
        result = process_image(image_path)
        return result
    else:
        return "No file selected"

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        uploaded_file = request.files['file']

        if uploaded_file.filename != '':
            # Save the uploaded file to a temporary location
            image_path = os.path.join('E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images', secure_filename(uploaded_file.filename))
            uploaded_file.save(image_path)

            result = process_image(image_path)

            # Remove the temporary image file
            #os.remove(image_path)
            print(result)
            if(result==0):
                return render_template('result.html', prediction="Healthy")
            elif(result==1):
                return render_template('result.html', prediction="Parkinson")
        else:
            return render_template('result.html', prediction="No file uploaded")
    else:
        return redirect(url_for('index'))

def mouse_callback_ensemble(event, x, y, flags, param):
    global mouse_pressed
    if event == cv2.EVENT_LBUTTONDOWN:
        mouse_pressed = True
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
    elif event == cv2.EVENT_LBUTTONUP:
        mouse_pressed = False
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
    elif event == cv2.EVENT_MOUSEMOVE and mouse_pressed:
        coordinates.append((x, y, 0, np.random.randint(3, 950)))
        with open('E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates_ensemble.csv', mode='a', newline='') as file:
            writer = csv.writer(file)
            if file.tell() == 0:
                writer.writerow(['X', 'Y', 'Z', 'Pressure'])
            writer.writerow([x, y, 0, np.random.randint(3, 950)])

def process_image_ensemble(image_path):
    global coordinates
    coordinates = []  # Reset coordinates
    image = cv2.imread(image_path)
    cv2.namedWindow("Image")
    cv2.setMouseCallback("Image", mouse_callback_ensemble)

    while True:
        cv2.imshow("Image", image)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            cv2.destroyAllWindows()  # Add this line to close the window
            break

    desired_length = 23000
    file_path = 'E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates_ensemble.csv'
    df = pd.read_csv(file_path)
        
    # Calculate the number of times to duplicate the rows
    stretch_factor = desired_length // len(df) + 1
        
    # Duplicate rows to reach the desired length
    stretched_df = pd.concat([df] * stretch_factor, ignore_index=True)
        
    # Truncate the DataFrame to the desired length
    stretched_df = stretched_df[:desired_length]
        
    # Save the stretched DataFrame back to the CSV file
    stretched_df.to_csv(file_path, index=False)
        
    print(f"Stretched coordinates.csv to a length of {desired_length} rows")


    test_file_path = 'E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images\coordinates_ensemble.csv'

    # Move the creation of the scaler inside the function
    #scaler = MinMaxScaler()
    
    """data = pd.read_csv(test_file_path)
    test_dataset = scaler.fit_transform(data)

    X_test = test_dataset[:, :]
    y_test = test_dataset[:, :-1]

    # Reshape the input features
    input_shape = (X_test.shape[1], 1)
    X_test = X_test.reshape(X_test.shape[0], *input_shape)

    # Predict labels using the trained model
    y_pred = model.predict(X_test)
    y_pred_labels = np.round(y_pred)  # Round to 0 or 1

    if all(y_pred_labels == 1):
        #result = "Parkinson's"
        #return render_template('result.html', prediction=result)
        result="Parkinson"
        print(f"Predicted label: {result}")
        return "Parkinson"
    else:
        #result = "Without Parkinson's"
        #return render_template('result.html', prediction="No file uploaded")
        result="Without Parkinson"
        print(f"Predicted label: {result}")
        return "Without Parkinson"""
        # Preprocess the test dataset
    #X_test = preprocess_csv(test_file_path, scaler)

    # Predict label using the trained model
    """y_pred = model.predict(X_test)
    print("Predicted Probabilities:", y_pred)
    y_pred_label = np.round(y_pred)[0][0]  # Round to 0 or 1

    # Display the predicted label
    if y_pred_label == 1:
        prediction = "Parkinson's"
    else:
        prediction = "Without Parkinson's"
    print(f"Predicted label: {prediction}")

    return prediction"""

    # Preprocess the test dataset
    X_test = preprocess_csv(test_file_path, scaler)
    X_test = np.expand_dims(X_test, axis=0)
    # Predict label using the loaded TensorFlow model
    result = inference(tf.convert_to_tensor(X_test, dtype=tf.float32))
    y_pred_label = np.round(result['output_1'][0][0])  # Assuming 'output_1' is the output name
    y_pred_label = (y_pred_label > 0.5).astype(int)
    mode_separate_predictions = mode(y_pred_label, axis=1).mode.flatten()
    inverted_prediction = 1 - mode_separate_predictions
    #inverted_predictions = []

    #inverted_predictions.append(inverted_prediction)

    # Display the predicted label
    """if y_pred_label == 1:
        prediction = "Parkinson's"
    else:
        prediction = "Without Parkinson's"
    print(f"Predicted label: {prediction}")"""

    return mode_separate_predictions[0]

@app.route('/predict_ensemble', methods=['GET', 'POST'])
def predict_ensemble():
    if request.method == 'POST':
        uploaded_file = request.files['file']

        if uploaded_file.filename != '':
            # Save the uploaded file to a temporary location
            image_path = os.path.join('E:\CAPSTONE_PROJECT\Main\main_dataset\spiral_images', secure_filename(uploaded_file.filename))
            uploaded_file.save(image_path)

            result = process_image_ensemble(image_path)

            # Remove the temporary image file
            #os.remove(image_path)
            print(result)
            if(result==0):
                return render_template('result.html', prediction="Healthy")
            elif(result==1):
                return render_template('result.html', prediction="Parkinson")
        else:
            return render_template('result.html', prediction="No file uploaded")
    else:
        return redirect(url_for('index'))

def calculate_shimmer(signal):
    # Replace this with your Shimmer calculation logic
    # This is just a placeholder; you need to implement your own calculation
    shimmer = np.mean(np.abs(np.diff(signal)))
    return shimmer

def calculate_shimmer_db(signal):
    # Replace this with your Shimmer(dB) calculation logic
    # This is just a placeholder; you need to implement your own calculation
    #shimmer_db = 20 * np.log10(np.mean(np.abs(np.diff(signal))))
    #return shimmer_db
    max_amplitude = np.max(np.abs(signal))
    min_amplitude = np.min(np.abs(signal))
    
    # Avoid division by zero
    if min_amplitude == 0:
        return float('inf')
    
    shimmer_db = (20 * np.log10(max_amplitude / min_amplitude))/100
    return shimmer_db
    
def calculate_apq(signal):
    # Replace this with your APQ calculation logic
    # This is just a placeholder; you need to implement your own calculation
    #apq = np.sum(np.square(np.diff(signal)))
    #return apq
    mad = np.mean(np.abs(np.diff(signal)))

    # Calculate the mean amplitude
    mean_amplitude = np.mean(np.abs(signal))

    # Calculate the APQ feature
    apq = mad / mean_amplitude

    return apq

def calculate_shimmer_dda(signal):
    # Replace this with your Shimmer:DDA calculation logic
    # This is just a placeholder; you need to implement your own calculation
    #shimmer_dda = np.sum(np.abs(np.diff(np.diff(signal))))
    #return shimmer_dda
    shimmer = np.abs(np.diff(signal))

    # Calculate Shimmer:DDA
    shimmer_dda = np.mean(np.abs(np.diff(shimmer)))
    return shimmer_dda

def calculate_rpde(signal):
    # Replace this with your RPDE calculation logic
    # This is just a placeholder; you need to implement your own calculation
    rpde = np.random.rand()  # Replace with actual calculation
    return rpde

def calculate_dfa(signal):
    # Replace this with your DFA calculation logic
    # This is just a placeholder; you need to implement your own calculation
    dfa = np.random.rand()  # Replace with actual calculation
    return dfa

def calculate_spread1(signal):
    # Replace this with your spread1 calculation logic
    # This is just a placeholder; you need to implement your own calculation
    spread1 = np.random.rand()  # Replace with actual calculation
    return spread1

def calculate_spread2(signal):
    # Replace this with your spread2 calculation logic
    # This is just a placeholder; you need to implement your own calculation
    spread2 = np.random.rand()  # Replace with actual calculation
    return spread2

def calculate_d2(signal):
    # Replace this with your D2 calculation logic
    # This is just a placeholder; you need to implement your own calculation
    d2 = np.random.rand()  # Replace with actual calculation
    return d2

def calculate_ppe(signal):
    # Replace this with your PPE calculation logic
    # This is just a placeholder; you need to implement your own calculation
    ppe = np.random.rand()  # Replace with actual calculation
    return ppe

def extract_voice_features(audio_file):
    y, sr = librosa.load(audio_file)

    shimmer = calculate_shimmer(y)
    shimmer_db = calculate_shimmer_db(y)
    apq = calculate_apq(y)
    shimmer_dda = calculate_shimmer_dda(y)
    rpde = calculate_rpde(y)
    dfa = calculate_dfa(y)
    spread1 = calculate_spread1(y)
    spread2 = calculate_spread2(y)
    d2 = calculate_d2(y)
    ppe = calculate_ppe(y)

    return {
        'Shimmer': shimmer,
        'Shimmer(dB)': shimmer_db,
        'APQ': apq,
        'Shimmer:DDA': shimmer_dda,
        'RPDE': rpde,
        'DFA': dfa,
        'spread1': spread1,
        'spread2': spread2,
        'D2': d2,
        'PPE': ppe
    }



@app.route('/calculate_features', methods=['POST'])
def calculate_features():
    if 'voiceInput' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['voiceInput']

    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    if file:
        # Save the file temporarily
        temp_file_path = r"C:\Users\Shrutesh Reddy\OneDrive\Desktop\Dataset_recording\temp.mp3"
        file.save(temp_file_path)

        # Extract features
        features = extract_voice_features(temp_file_path)

        # Remove the temporary file
        # You might want to handle file removal more carefully in a production setting
        import os
        os.remove(temp_file_path)

        # Render the results template with the extracted features
        return render_template('result_dbn1.html', features=features)

@app.route('/calculate_ensemble_features', methods=['POST'])
def calculate_ensemble_features():
    if 'voiceInput' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['voiceInput']

    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    if file:
        # Save the file temporarily
        temp_file_path = r"C:\Users\Shrutesh Reddy\OneDrive\Desktop\Dataset_recording\temp.mp3"
        file.save(temp_file_path)

        # Extract features
        features = extract_voice_features(temp_file_path)

        # Remove the temporary file
        # You might want to handle file removal more carefully in a production setting
        import os
        os.remove(temp_file_path)

        # Render the results template with the extracted features
        return render_template('result_Ensemble1.html', features=features)

@app.route('/predict_dbn', methods=['POST'])
def predict_dbn():
    if request.method == 'POST':
        # Get the input values from the form
        features = [
            float(request.form['MDVP:Shimmer']),
            float(request.form['MDVP:Shimmer(dB)']),
            float(request.form['MDVP:APQ']),
            float(request.form['Shimmer:DDA']),
            float(request.form['RPDE']),
            float(request.form['DFA']),
            float(request.form['spread1']),
            float(request.form['spread2']),
            float(request.form['D2']),
            float(request.form['PPE'])
        ]

        # Standardize the input features using the scaler
        input_features = scaler1.transform([features])

        # Make a prediction using your ML model
        prediction = model_dbn.predict(input_features)

        # Convert the prediction to 'Parkinson' or 'Healthy' based on a threshold
        threshold = 0.5
        result = 'Parkinson' if prediction > threshold else 'Healthy'

        return render_template('result_dbn2.html', prediction=result)


@app.route('/ensemble_dbn', methods=['POST'])
def ensemble_dbn():
    if request.method == 'POST':
        # Get the input values from the form
        features = [
            float(request.form['MDVP:Shimmer']),
            float(request.form['MDVP:Shimmer(dB)']),
            float(request.form['MDVP:APQ']),
            float(request.form['Shimmer:DDA']),
            float(request.form['RPDE']),
            float(request.form['DFA']),
            float(request.form['spread1']),
            float(request.form['spread2']),
            float(request.form['D2']),
            float(request.form['PPE'])
        ]

        # Standardize the input features using the scaler
        input_features = scaler1.transform([features])

        # Make a prediction using your ML model
        prediction = model_dbn.predict(input_features)

        # Convert the prediction to 'Parkinson' or 'Healthy' based on a threshold
        threshold = 0.5
        result = 'Parkinson' if prediction > threshold else 'Healthy'

        return render_template('result_Ensemble2.html', prediction=result)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_from_tkinter', methods=['GET'])
def predict_from_tkinter_route():
    result = predict_from_tkinter()
    return render_template('result.html', prediction=result)

# ... (rest of your routes remain unchanged)
@app.route('/dbn')
def dbn():
    return render_template('DBN.html')

@app.route('/cnn')
def cnn():
    return render_template('CNN.html')

@app.route('/ensemble')
def ensemble():
    return render_template('Ensemble.html')

@app.route('/news')
def news():
    return render_template('index_news.html')

@app.route('/contact')
def contact():
    return render_template('index_contact.html')



if __name__ == '__main__':
    app.run(debug=True)
