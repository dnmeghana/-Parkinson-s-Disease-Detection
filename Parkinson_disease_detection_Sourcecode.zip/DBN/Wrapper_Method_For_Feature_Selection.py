import pandas as pd
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

# Load your dataset from a CSV file
data = pd.read_csv("/content/parkinsons (copy).csv")

# Separate features (X) and target (y)
X = data.drop(columns=['name','status'])
y = data['status']

# Initialize the logistic regression model
model = LogisticRegression()

# Initialize the RFE with the model and the desired number of features
num_features_to_select = 10  # You can change this as needed
rfe = RFE(estimator=model, n_features_to_select=num_features_to_select)

# Fit RFE on the data
rfe.fit(X, y) //rfe = Recursive Feature Elimination

# Get selected features
selected_features = X.columns[rfe.support_]

# Display the selected features
print("Selected Features:")
print(selected_features)