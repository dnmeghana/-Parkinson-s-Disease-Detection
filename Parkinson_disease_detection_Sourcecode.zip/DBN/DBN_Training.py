import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GaussianNoise
from tensorflow.keras.optimizers import SGD
from sklearn.metrics import accuracy_score

# Load your data
data = pd.read_csv("/content/drive/MyDrive/PARKINSON/new_training_augmented_data.csv")

# Select the desired columns as features and target variable
features = data[['MDVP:Shimmer', 'MDVP:Shimmer(dB)', 'MDVP:APQ', 'Shimmer:DDA', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE']]
target = data['status']

# Split the data into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(features, target, test_size=0.2, random_state=42)

# Standardize the feature data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)

# Define a function to create an RBM layer
def rbm_layer(hidden_units):
    rbm = tf.keras.layers.Dense(hidden_units, activation='relu')
    return rbm

# Build the DBN with RBM layers
model = Sequential()
model.add(GaussianNoise(0.1, input_shape=(10,)))  # Add noise to the input
model.add(rbm_layer(512))
model.add(Dense(256, activation='relu'))
model.add(Dense(128, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(optimizer=SGD(lr=0.01, momentum=0.9), loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_val, y_val))

# Evaluate the model on validation data
y_val_pred = model.predict(X_val)
y_val_pred_binary = (y_val_pred > 0.5).astype(int)
accuracy = accuracy_score(y_val, y_val_pred_binary)
print(f"Validation Accuracy: {accuracy}")

# Save the trained model
model.save("dbn_model_new.h5")