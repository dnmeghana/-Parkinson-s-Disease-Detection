import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow.keras.models import load_model
from sklearn.metrics import accuracy_score, confusion_matrix

validation_data = pd.read_csv("/content/drive/MyDrive/testing.csv")

# Select the desired columns as features
validation_features = validation_data[['MDVP:Shimmer', 'MDVP:Shimmer(dB)', 'MDVP:APQ',
'Shimmer:DDA', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE']]

# Standardize the validation feature data using the same scaler from training
scaler = StandardScaler()
validation_features = scaler.fit_transform(validation_features)

# Load the saved model
model = load_model("/content/dbn_model_new.h5")# Make predictions on the validation data
y_validation_pred = model.predict(validation_features)

# Convert predicted values to 0 or 1 based on a threshold (e.g., 0.5)
threshold = 0.5
predicted_status = (y_validation_pred > threshold).astype(int)
# Extract and print the 'status' column
actual_status = validation_data['status'].values
print("Actual 'status' values:")
print(actual_status)
print("Predicted 'status' values:")
print(predicted_status.flatten())

# Calculate accuracy
accuracy = accuracy_score(actual_status, predicted_status)
print("Accuracy:", accuracy)

# Calculate and print confusion matrix
confusion = confusion_matrix(actual_status, predicted_status)
print("Confusion Matrix:")
print(confusion)