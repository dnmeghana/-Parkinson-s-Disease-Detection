import pandas as pd
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from scipy.stats import mode
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import load_model
from sklearn.metrics import accuracy_score, confusion_matrix

loaded_model = tf.keras.models.load_model('/content/drive/MyDrive/saved_model')

separate_test_csv_path = '/content/drive/MyDrive/testing.csv'
separate_test_csv = pd.read_csv(separate_test_csv_path)
base_path = '/content/drive/MyDrive/TESTING'  # Adjust this path as needed
validation_features = separate_test_csv[['MDVP:Shimmer', 'MDVP:Shimmer(dB)', 'MDVP:APQ','Shimmer:DDA', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE']]
scaler = StandardScaler()
validation_features = scaler.fit_transform(validation_features)

separate_test_csv = pd.read_csv(separate_test_csv_path)

separate_test_file_names = separate_test_csv['file_name'].tolist()
separate_test_target_values = separate_test_csv['status'].values
count=0
separate_test_data_list = []
for file_name in separate_test_file_names:
    count+=1
    file_path = os.path.join(base_path, file_name)
    data = pd.read_csv(file_path)
    data = data.iloc[:, :-1]  
    data = data.astype('float32')  
    separate_test_data_list.append(data.values)

separate_test_data_array = np.array(separate_test_data_list)
separate_test_data_array = separate_test_data_array.astype('float32')

separate_predictions = loaded_model.predict(separate_test_data_array)
model = load_model("/content/dbn_model_new (2).h5")# Make predictions on the validation data
y_validation_pred = model.predict(validation_features)
binary_separate_predictions = (separate_predictions > 0.5).astype(int)
threshold = 0.5
predicted_status = (y_validation_pred > threshold).astype(int)

mode_separate_predictions = mode(binary_separate_predictions, axis=1).mode.flatten()

actual_values = []
inverted_predictions = []

for j in range(count):
    file_name=separate_test_file_names[j]
    file_indices = [i for i, name in enumerate(separate_test_file_names) if name == file_name]
    mode_prediction = mode_separate_predictions[file_indices[0]]
    actual_value = separate_test_target_values[file_indices[0]]
    inverted_prediction = 1 - mode_prediction
    inverted_predictions.append(inverted_prediction)
final=[]
for j in range(count):
    x=(inverted_predictions[j]+predicted_status[j])/2
    if x==0.5:
      final.append(int(inverted_predictions[j]))
      x=inverted_predictions[j]
    else:
      final.append(int(x))
    print(f"Actual: {separate_test_target_values[j]}, Predicted: {x}")
print(final)
print(separate_test_target_values)
accuracy = accuracy_score(separate_test_target_values, final)
print(f"\nAccuracy: {accuracy * 100:.2f}%")